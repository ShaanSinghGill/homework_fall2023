1) See hw1 if you'd like to see installation instructions. You do NOT have to redo them.
2) See the PDF for the rest of the instructions.


python cs285/scripts/run_hw4.py -cfg experiments/mpc/reacher_ablation1.yaml
python cs285/scripts/run_hw4.py -cfg experiments/mpc/reacher_ablation2.yaml
python cs285/scripts/run_hw4.py -cfg experiments/mpc/reacher_ablation3.yaml
python cs285/scripts/run_hw4.py -cfg experiments/mpc/reacher_ablation4.yaml
python cs285/scripts/run_hw4.py -cfg experiments/mpc/reacher_ablation5.yaml
python cs285/scripts/run_hw4.py -cfg experiments/mpc/reacher_ablation6.yaml
