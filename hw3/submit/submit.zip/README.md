Assignments for [Berkeley CS 285: Deep Reinforcement Learning, Decision Making, and Control](http://rail.eecs.berkeley.edu/deeprlcourse/).

I used all the default commands. Only for hyperparameter tuning did I have new ones: 
python cs285/scripts/run_hw3_sac.py -cfg experiments/dqn/hyperparameters/cartpole1.yaml           
python cs285/scripts/run_hw3_sac.py -cfg experiments/dqn/hyperparameters/cartpole2.yaml   
python cs285/scripts/run_hw3_sac.py -cfg experiments/dqn/hyperparameters/cartpole3.yaml   
python cs285/scripts/run_hw3_sac.py -cfg experiments/dqn/hyperparameters/cartpole4.yaml   

